export default function DashboardLayout({ children }) {
  return <div id="wrapper">{children}</div>;
}
