export default function ManageDiscounts() {
  return <div>ManageDiscounts</div>;
}
