export default function ManageOrders() {
  return (
    <div>Manage Orders</div>
  )
}
