export default function ManageProducts() {
  return <div>ManageProducts</div>;
}
